#!/usr/bin/env python3
import sys

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from sensor_msgs.msg import CompressedImage

from cv_bridge import CvBridge
import cv2
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import CompressedImage
import numpy as np
from collections import defaultdict
from geometry_msgs.msg import Twist
import os
from ament_index_python.packages import get_package_share_directory
from std_msgs.msg import Bool
import time




class CameraSubscriber(Node):
    def __init__(self):
        super().__init__('camera_subscriber')
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.listener_callback,
            qos_profile=qos_profile_sensor_data
        )
        # self.create_subscription(Image,'/image_raw/compressed',self.listener_callback,10)
        self.bridge = CvBridge()
        self.horizon_line_y = None  
        self.line_drawn = False
        self.prev_gray = None  # Store previous frame in grayscale
        self.stored_intersections = []
        self.velocity_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.stop_publisher = self.create_publisher(Bool, '/stop', 10)
        package_share_directory = get_package_share_directory('enpm673_final_proj')
        cascade_path = os.path.join(package_share_directory, 'stop_sign_classifier_2.xml')
        self.stop_sign_cascade = cv2.CascadeClassifier(cascade_path)
        if self.stop_sign_cascade.empty():
            self.get_logger().error('Failed to load cascade classifier from {}'.format(cascade_path))
            raise Exception('Failed to load cascade classifier')
    
    def publish_constant_velocity(self, linear_speed, angular_speed):
        vel_msg = Twist()
        vel_msg.linear.x = linear_speed  # Adjust this value to set your desired speed
        vel_msg.angular.z = angular_speed  # No angular movement
        self.velocity_publisher.publish(vel_msg)


    def find_intersections(self, lines):
        intersections = []
        for i in range(len(lines)):
            for j in range(i + 1, len(lines)):
                line1 = lines[i][0]
                line2 = lines[j][0]
                theta1, rho1 = line1[1], line1[0]
                theta2, rho2 = line2[1], line2[0]
                A = np.array([
                    [np.cos(theta1), np.sin(theta1)],
                    [np.cos(theta2), np.sin(theta2)]
                ])
                b = np.array([[rho1], [rho2]])
                try:
                    intersection = np.linalg.solve(A, b)
                    intersections.append((int(intersection[0]), int(intersection[1])))
                except np.linalg.LinAlgError:
                    continue  # No solution, lines are parallel
        return intersections
    
    def compute_horizon_line(self, intersections, cv_image):
        y_coords = [y for _, y in intersections]
        if y_coords:
            y_hist = defaultdict(int)
            for y in y_coords:
                y_hist[y] += 1
            most_frequent_y = max(y_hist, key=y_hist.get)
            self.horizon_line_y = most_frequent_y
            self.stored_intersections = intersections

    # def compute_horizon_line(self, intersections, cv_image):
    #     y_coords = [y for _, y in intersections]
    #     if y_coords:
    #         average_y = int(sum(y_coords) / len(y_coords))  # Calculate the average of y-coordinates
    #         self.horizon_line_y = average_y
    #         self.stored_intersections = intersections

    def draw_horizon_line(self, cv_image):
        if self.horizon_line_y is not None:
            self.line_drawn = True
            cv2.line(cv_image, (0, self.horizon_line_y), (cv_image.shape[1], self.horizon_line_y), (255, 0, 0), 2)

    def listener_callback(self, msg):
        cv_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')

        scale_percent = 50  # percent of original size
        width = int(cv_image.shape[1] * scale_percent / 100)
        height = int(cv_image.shape[0] * scale_percent / 100)
        dim = (width, height)
        resized = cv2.resize(cv_image, dim, interpolation=cv2.INTER_AREA)
        gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
        gray_real = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

        if not self.line_drawn:
            print('Drawing horizon line')
            blurred = cv2.GaussianBlur(gray, (3, 3), 0)
            edges = cv2.Canny(blurred, 75, 150)
            lines = cv2.HoughLines(edges, 0.85 , np.pi/180, 50, min_theta= (-np.pi/3), max_theta= (np.pi/3))


            if lines is not None and self.horizon_line_y is None:
                n_line = []
                for line in lines:
                    rho, theta = line[0]
                    if abs(theta - np.pi/90) < np.pi/9:
                        continue
                    n_line.append(line)
                intersections = self.find_intersections(n_line)
                scaled_intersections = [(int(x * 100 / scale_percent), int(y * 100 / scale_percent)) for x, y in intersections]
                self.compute_horizon_line(scaled_intersections, cv_image)
        if self.line_drawn:
            stop_signs = self.stop_sign_cascade.detectMultiScale(gray_real, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
            if len(stop_signs) > 0:
                # self.publish_constant_velocity(0.0, 0.0)
                # self.publish_constant_velocity(0.0, 0.0)
                # self.publish_constant_velocity(0.0, 0.0)
                # self.publish_constant_velocity(0.0, 0.0)
                stop_message = Bool(data=True)
                self.stop_publisher.publish(stop_message)
                # time.sleep(0.25)
                for (x, y, w, h) in stop_signs:
                    # x, y, w, h = x * 100 // scale_percent, y * 100 // scale_percent, w * 100 // scale_percent, h * 100 // scale_percent
                    cv2.rectangle(cv_image, (x, y), (x + w, y + h), (0, 0, 255), 2)
                    # cv2.putText(cv_image, 'STOP', (x, y + 12), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
            else:
                stop_message = Bool(data=False)
                self.stop_publisher.publish(stop_message)
            for x, y in self.stored_intersections:
                x = int(x)
                y = int(y)
                # try:
                #     cv2.circle(cv_image, (x, y), 2, (0, 0, 255), -1)
                # except:
                #     print('Error drawing circle')
        self.draw_horizon_line(cv_image)
            
        # self.publish_constant_velocity(0.0, 0.0)
        
        if self.line_drawn:
            if self.prev_gray is not None:
                flow = cv2.calcOpticalFlowFarneback(self.prev_gray, gray, None, 0.5, 3, 15, 3, 5, 1.2, 0)
                # mag, angle = cv2.cartToPolar(flow[..., 0], flow[..., 1])
                motion_x, motion_y = flow[..., 0], flow[..., 1]
                # print(np.abs(motion_x))
                motion_mask = np.abs(motion_x) > 14
                # print(f"over")
                motion_mask = motion_mask.astype(np.uint8) * 255

                _, thresh = cv2.threshold(motion_mask, 60, 255, cv2.THRESH_BINARY)
                contours, _ = cv2.findContours(thresh.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for contour in contours:
                    x, y, w, h = cv2.boundingRect(contour)
                    # Scale contour bounding box back to original image size
                    x, y, w, h = x * 100 // scale_percent, y * 100 // scale_percent, w * 100 // scale_percent, h * 100 // scale_percent

                    # Check if the contour is below the horizon line
                    if y + h/2 >= self.horizon_line_y:
                        if cv2.contourArea(contour) > 100:  # filter out small movements
                            stop_message = Bool(data=True)
                            self.stop_publisher.publish(stop_message)
                            self.publish_constant_velocity(0.0, 0.0)
                            print(cv2.contourArea(contour))
                            cv2.rectangle(cv_image, (x, y), (x + w, y + h), (0, 255, 0), 2)
                        elif len(stop_signs) == 0:
                            stop_message = Bool(data=False)
                            self.stop_publisher.publish(stop_message)
            self.prev_gray = gray
        # cv2.imshow('Camera Image', resized)
        cv2.imshow('Camera Image', cv_image)
        cv2.waitKey(1)



def main(args=None):
    rclpy.init(args=args)
    camera_subscriber = CameraSubscriber()
    rclpy.spin(camera_subscriber)
    camera_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
