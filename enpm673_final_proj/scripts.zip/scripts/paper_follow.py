#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool
from cv_bridge import CvBridge
import cv2
import numpy as np
import math
import time

class PaperFollowerNode(Node):
    def __init__(self):
        super().__init__('paper_follower_node')
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10)
        self.switch = 0
        self.stop_l =0
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.stop_subscriber = self.create_subscription(Bool, '/stop', self.stop_callback, 10)
        self.processed_image_publisher = self.create_publisher(Image, '/processed_image', 10)
        self.bridge = CvBridge()
        self.right_start_time = 0
        self.fov_horizontal = 62.2  # Horizontal field of view of the camera
        self.state = "searching"  # Possible states: "searching", "driving", "returning"
        self.contour_areas = []  # Initialize the contour_areas list
        self.no_paper= 0
        self.stop = 0
    def stop_callback(self, msg):
        if msg.data:  # If the message data is True
            # print(msg.data)
            self.get_logger().info('Stop signal received, stopping the robot.')
            twist = Twist()
            twist.linear.x = 0.0  # Set linear velocity to 0
            twist.angular.z = 0.0  # Set angular velocity to 0
            self.publisher.publish(twist)
            self.stop = 1
        else:
            self.get_logger().info('Continue signal received, resuming normal operation.')
            self.stop = 0

            # Here, you could add code to resume normal operation if needed


    def find_and_draw_paper(self, image):
        height = image.shape[0]
        cropped_image = image[height // 2:height, :]  # Take the lower half
        hsv = cv2.cvtColor(cropped_image, cv2.COLOR_BGR2HSV)

        # Define range for white color
        lower_white = np.array([0, 0, 168], dtype=np.uint8)
        upper_white = np.array([172, 111, 255], dtype=np.uint8)

        # Threshold the HSV image to get only white colors
        mask = cv2.inRange(hsv, lower_white, upper_white)
        kernel = np.ones((5, 5), np.uint8)
        opening = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        # Find contours
        contours, _ = cv2.findContours(opening, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None, None, image, 0  # No contours found

        # Get the largest contour based on contour area
        largest_contour = max(contours, key=cv2.contourArea)
        
        # Calculate the area of the largest contour
        contour_area = cv2.contourArea(largest_contour)
        if contour_area == None:
            contour_area = 0
        
        M = cv2.moments(largest_contour)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
        else:
            return None, None, image, 0

        # Draw the largest contour and the centroid
        cv2.drawContours(cropped_image, [largest_contour], -1, (0, 255, 0), 2)
        cv2.circle(cropped_image, (cX, cY), 5, (255, 0, 0), -1)
        image[height // 2:height, :] = cropped_image
        # self.get_logger().info(f'The robot found center at {cX}. Contour area: {contour_area}')

        return cX, image.shape[1], image,contour_area


    def calculate_turn_angle(self, cX, image_width):
        # Calculate the horizontal field of view in radians
        fov_rad = math.radians(self.fov_horizontal)

        # Calculate the offset from the center of the image
        offset_from_center = cX - (image_width / 2)

        # Calculate the angle as a proportion of the field of view
        angle_to_turn = (offset_from_center / (image_width / 2)) * (self.fov_horizontal / 2)

        # Determine the direction to turn
        direction = "right" if offset_from_center > 0 else "left"

        return angle_to_turn, direction

    def search_for_paper(self):
        # Turn the robot left and right to search for paper
        twist = Twist()
        if self.state == "searching":
            twist.angular.z = 0.3  # Turn left
            twist.linear.x = 0.0
            self.state = "turning_left"
            self.publisher.publish(twist)

        elif self.state == "turning_left":
            twist.angular.z = -0.3  # Turn right
            twist.linear.x = 0.0
            self.state = "turning_right"
            self.publisher.publish(twist)
        elif self.state == "turning_right":
            self.state = "returning"  # Return to home if not found
        self.publisher.publish(twist)

    def go_to_home_position(self):
        twist = Twist()

        # Code to go back to the home position
        # self.get_logger().info('Returning to home position.')
        # Implement home positioning logic here
        twist.angular.z = 0.0
        self.publisher.publish(twist)

    def publish_processed_image(self, processed_image):
        processed_image_msg = self.bridge.cv2_to_imgmsg(processed_image, encoding='bgr8')
        self.processed_image_publisher.publish(processed_image_msg)

    def image_callback(self, msg):
        cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        cX, image_width, processed_image, con_area = self.find_and_draw_paper(cv_image)
        self.contour_areas.append(con_area)

        if len(self.contour_areas) > 25:
                self.contour_areas.pop(0)

            # Calculate the average of the latest 25 contour_area values
        avg_contour_area = sum(self.contour_areas) / len(self.contour_areas)
        if avg_contour_area <3000:
            self.switch =1
        else:
            self.switch = 0
        twist = Twist()
        if not self.stop:
            if cX is not None and self.switch ==0:
                self.no_paper= 0
                angle, direction = self.calculate_turn_angle(cX, image_width)
                # self.get_logger().info(f'The robot needs to turn {angle:.2f} degrees to the {direction}.')
                self.state = "driving"
                
                angular_z = -angle * math.pi / 180  # Negative for clockwise rotation
                twist.angular.z = angular_z
                twist.linear.x = 0.1  # Move forward at a slow rate
                self.publisher.publish(twist)
            else:
                self.get_logger().info('No paper detected, searching...')
                # twist.angular.z = 0.0
                # twist.linear.x = 0.0  # Move forward at a slow rate
                if self.state != "turning_left" and self.no_paper==0:
                    self.left_start_time = time.time()
                    self.get_logger().info(f'started turning at {self.left_start_time} seconds.')
                    self.state = "turning_left"
                    self.no_paper=1
                    
                if time.time() - self.left_start_time <= 3.5 and self.no_paper==1:
                    twist.angular.z = 0.5  # Turn left
                    # self.get_logger().info(f'Thurning left for {self.left_start_time} seconds. and current time is {time.time()}')

                    
                elif time.time() - self.left_start_time > 3.5 and self.stop_l == 0:
                    self.state = "searching"  # Reset state after 5 seconds of left turn
                    twist.angular.z = 0.0
                    twist.linear.x = 0.0
                    self.publisher.publish(twist)
                    self.stop_l = 1
                    # self.switch = 0
                    self.right_start_time = time.time()
                
                if time.time()- self.right_start_time <=3.5 and self.stop_l == 1:
                    twist.angular.z = -0.5
                    # self.get_logger().info(f'Thurning right for {time.time() - self.left_start_time} seconds.')
                
                elif time.time() - self.right_start_time > 3.5 and self.stop_l == 1:
                    twist.angular.z = 0.0
                    twist.linear.x = 0.0
                    self.publisher.publish(twist)
                    self.stop_l = 0                


                if self.state == "returning":
                    self.go_to_home_position()
                else:
                    self.publisher.publish(twist)



                self.state = "turning"
                # self.search_for_paper()
                # self.publisher.publish(twist)
                if self.state == "returning":
                    self.go_to_home_position()
                    self.switch = 0

            # Publish the processed image for visualization
            self.publish_processed_image(processed_image)

def main(args=None):
    rclpy.init(args=args)
    paper_follower_node = PaperFollowerNode()
    rclpy.spin(paper_follower_node)
    paper_follower_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

